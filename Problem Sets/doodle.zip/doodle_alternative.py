###################################
##########  PROBLEM 5-4 ###########
###################################


def rec2(i1, i2, len1, len2, ghost1, ghost2, cache, move_cache):
    if i1 == len1 and i2 == len2:
        return 0
    if cache[i1][i2] is not None:
        return cache[i1][i2]
    res = (len1 - i1) + (len2 - i2)
    by = None
    if i1 < len1 and i2 < len2:
        if ghost1[i1] == ghost2[i2]:
            by = 3
            res = rec2(i1 + 1, i2 + 1, len1, len2, ghost1, ghost2, cache, move_cache) + 1
        else:
            by = 1
            res = rec2(i1 + 1, i2, len1, len2, ghost1, ghost2, cache, move_cache) + 1
            candidate = rec2(i1, i2 + 1, len1, len2, ghost1, ghost2, cache, move_cache) + 1
            if res > candidate:
                res = candidate
                by = 2
    cache[i1][i2] = res
    move_cache[i1][i2] = by
    return res

def double_kill(ghost1, ghost2):
    """
    Compute the shortest move sequence which will make both ghosts disappear.

    Parameters
    ----------
    ghost1: []
        ordered list of moves which will make ghost1 disappear
    ghost2: []
        ordered list of moves which will make ghost2 disappear

    Returns
    -------
    seq : []
        move sequence of minimal length which will make both ghosts disappear
    """

    len1, len2 = len(ghost1), len(ghost2)
    cache = [[None for i2 in range(len2 + 1)] for i1 in range(len1 + 1)]
    move_cache = [[None for i2 in range(len2 + 1)] for i1 in range(len1 + 1)]
    for i1 in reversed(range(len1)):
        for i2 in reversed(range(len2)):
            rec2(i1, i2, len1, len2, ghost1, ghost2, cache, move_cache)
    i1, i2 = 0, 0
    seq = []
    while i1 < len1 and i2 < len2:
        assert move_cache[i1][i2] is not None
        if move_cache[i1][i2] == 1:
            seq.append(ghost1[i1])
            i1 += 1
        elif move_cache[i1][i2] == 2:
            seq.append(ghost2[i2])
            i2 += 1
        else:
            assert ghost1[i1] == ghost2[i2]
            seq.append(ghost1[i1])
            i1 += 1
            i2 += 1
    while i1 < len1:
        seq.append(ghost1[i1])
        i1 += 1
    while i2 < len2:
        seq.append(ghost2[i2])
        i2 += 1
    print(seq)
    return seq



#
# PART B: Fill in the code for part b
#

def triple_kill(ghost1, ghost2, ghost3):
    """
    Compute the shortest move sequence which will make all three ghosts disappear.

    Parameters
    ----------
    ghost1: []
        ordered list of moves which will make ghost1 disappear
    ghost2: []
        ordered list of moves which will make ghost2 disappear
    ghost3: []
        ordered list of moves which will make ghost3 disappear

    Returns
    -------
    seq : []
        move sequence of minimal length which will make all three ghosts disappear
    """
    len0, len1, len2 = len(ghost1), len(ghost2), len(ghost3)
    lens = [len0, len1, len2]
    ghost = [ghost1, ghost2, ghost3]
    inf = len0 + len1 + len2 + 1
    by = [[[None for i2 in range(len2 + 1)] for i1 in range(len1 + 1)] for i0 in range(len0 + 1)]
    best = [[[inf for i2 in range(len2 + 1)] for i1 in range(len1 + 1)] for i0 in range(len0 + 1)]

    by[len0][len1][len2] = None
    best[len0][len1][len2] = 0
    for i0 in reversed(range(len0 + 1)):
        for i1 in reversed(range(len1 + 1)):
            for i2 in reversed(range(len2 + 1)):
                for index in range(3):
                    j = [i0, i1, i2]
                    if j[index] < lens[index]:
                        deltas = 1 << index
                        for k in range(3):
                            if (k != index and j[k] < lens[k] and
                                    ghost[k][j[k]] == ghost[index][j[index]]):
                                j[k] += 1
                                deltas |= 1 << k
                        j[index] += 1
                        candidate = best[j[0]][j[1]][j[2]] + 1
                        if best[i0][i1][i2] > candidate:
                            best[i0][i1][i2] = candidate
                            by[i0][i1][i2] = deltas
    # Reconstruct solution.
    seq = []
    j = [0, 0, 0]
    while j < lens:
        deltas = by[j[0]][j[1]][j[2]]
        for i in range(len(lens)):
            if ((deltas >> i) & 1) > 0:
                seq.append(ghost[i][j[i]])
                break
        for i in range(len(lens)):
            j[i] += ((deltas >> i) & 1)
    print(seq)
    return seq
