###################################
##########  PROBLEM 5-4 ###########
###################################
#
# PART A: Fill in the code for part a
#
def double_kill(ghost1, ghost2):
    """
    Compute the shortest move sequence which will make both ghosts disappear.

    Parameters
    ----------
    ghost1: []
        ordered list of moves which will make ghost1 disappear. Each move is a single character, 'A', 'B', etc.
    ghost2: []
        ordered list of moves which will make ghost2 disappear. Each move is a single character, 'A', 'B', etc.

    Returns
    -------
    seq : []
        move sequence of minimal length which will make both ghosts disappear. Each move should be a single character, 'A', 'B', etc.
    """
    # YOUR CODE HERE

    len1 = len(ghost1)
    len2 = len(ghost2)
    max_len = len1 + len2 + 10
    best_len = []
    for ii in range(len1 + 1):
        best_len.append([max_len] * (len2 + 1))
    parent = []
    for ii in range(len1 + 1):
        parent.append([(0, 0)] * (len2 + 1))

    best_len[0][0] = 0
    for ii in range(1, len1 + 1):
        best_len[ii][0] = ii
        parent[ii][0] = (ii - 1, 0)
    for jj in range(1, len2 + 1):
        best_len[0][jj] = jj
        parent[0][jj] = (0, jj - 1)

    for ii in range(1, len1 + 1):
        for jj in range(1, len2 + 1):
            if ghost1[ii - 1] == ghost2[jj - 1]:
                best_len[ii][jj] = best_len[ii - 1][jj - 1] + 1
                parent[ii][jj] = (ii - 1, jj - 1)
            else:
                if best_len[ii - 1][jj] <= best_len[ii][jj - 1]:
                    best_len[ii][jj] = best_len[ii - 1][jj] + 1
                    parent[ii][jj] = (ii - 1, jj)
                else:
                    best_len[ii][jj] = best_len[ii][jj - 1] + 1
                    parent[ii][jj] = (ii, jj - 1)

    sol = []
    cur = (len1, len2)
    sol_len = best_len[cur[0]][cur[1]]
    for ii in range(sol_len):
        next_pos = parent[cur[0]][cur[1]]
        if next_pos[0] != cur[0]:
            sol.append(ghost1[next_pos[0]])
        else:
            sol.append(ghost2[next_pos[1]])
        cur = next_pos

    # return list(reversed(sol)), best_len, parent
    return list(reversed(sol))


#
# PART B: Fill in the code for part b
#

def double_kill_subroutine(ghost1, ghost2):
    len1 = len(ghost1)
    len2 = len(ghost2)
    max_len = len1 + len2 + 10
    best_len = []
    for ii in range(len1 + 1):
        best_len.append([max_len] * (len2 + 1))
    parent = []
    for ii in range(len1 + 1):
        parent.append([(0, 0)] * (len2 + 1))

    best_len[0][0] = 0
    for ii in range(1, len1 + 1):
        best_len[ii][0] = ii
        parent[ii][0] = (ii - 1, 0)
    for jj in range(1, len2 + 1):
        best_len[0][jj] = jj
        parent[0][jj] = (0, jj - 1)

    for ii in range(1, len1 + 1):
        for jj in range(1, len2 + 1):
            if ghost1[ii - 1] == ghost2[jj - 1]:
                best_len[ii][jj] = best_len[ii - 1][jj - 1] + 1
                parent[ii][jj] = (ii - 1, jj - 1)
            else:
                if best_len[ii - 1][jj] <= best_len[ii][jj - 1]:
                    best_len[ii][jj] = best_len[ii - 1][jj] + 1
                    parent[ii][jj] = (ii - 1, jj)
                else:
                    best_len[ii][jj] = best_len[ii][jj - 1] + 1
                    parent[ii][jj] = (ii, jj - 1)
    return best_len, parent

def triple_kill(ghost0, ghost1, ghost2):
    """
    Compute the shortest move sequence which will make all three ghosts disappear.

    Parameters
    ----------
    ghost1: []
        ordered list of moves which will make ghost1 disappear. Each move is a single character, 'A', 'B', etc.
    ghost2: []
        ordered list of moves which will make ghost2 disappear. Each move is a single character, 'A', 'B', etc.
    ghost3: []
        ordered list of moves which will make ghost2 disappear. Each move is a single character, 'A', 'B', etc.

    Returns
    -------
    seq : []
        move sequence of minimal length which will make all three ghosts disappear. Each move should be a single character, 'A', 'B', etc.
    """
    # YOUR CODE HERE

    len0 = len(ghost0)
    len1 = len(ghost1)
    len2 = len(ghost2)
    max_len = len0 + len1 + len2 + 10

    # Setup 3D matrices
    best_len = []
    for ii in range(len0 + 1):
        tmp = []
        for jj in range(len1 + 1):
            tmp.append([max_len] * (len2 + 1))
        best_len.append(tmp)
    parent = []
    for ii in range(len0 + 1):
        tmp = []
        for jj in range(len1 + 1):
            tmp.append([(0, 0, 0)] * (len2 + 1))
        parent.append(tmp)

    # Initialize boundary
    bl, par = double_kill_subroutine(ghost0, ghost1)
    for ii in range(len0 + 1):
        for jj in range(len1 + 1):
            best_len[ii][jj][0] = bl[ii][jj]
            parent[ii][jj][0] = (par[ii][jj][0], par[ii][jj][1], 0)
    bl, par = double_kill_subroutine(ghost0, ghost2)
    for ii in range(len0 + 1):
        for jj in range(len2 + 1):
            best_len[ii][0][jj] = bl[ii][jj]
            parent[ii][0][jj] = (par[ii][jj][0], 0, par[ii][jj][1])
    bl, par = double_kill_subroutine(ghost1, ghost2)
    for ii in range(len1 + 1):
        for jj in range(len2 + 1):
            best_len[0][ii][jj] = bl[ii][jj]
            parent[0][ii][jj] = (0, par[ii][jj][0], par[ii][jj][1])

    # DP
    for ii in range(1, len0 + 1):
        for jj in range(1, len1 + 1):
            for kk in range(1, len2 + 1):
                # All three moves match
                if (ghost0[ii - 1] == ghost1[jj - 1]) and (ghost1[jj - 1] == ghost2[kk - 1]):
                    best_len[ii][jj][kk] = best_len[ii - 1][jj - 1][kk - 1] + 1
                    parent[ii][jj][kk] = (ii - 1, jj - 1, kk - 1)
                # Two moves match (first and second ghost)
                elif ghost0[ii - 1] == ghost1[jj - 1]:
                    if best_len[ii - 1][jj - 1][kk] <= best_len[ii][jj][kk - 1]:
                        best_len[ii][jj][kk] = best_len[ii - 1][jj - 1][kk] + 1
                        parent[ii][jj][kk] = (ii - 1, jj - 1, kk)
                    else:
                        best_len[ii][jj][kk] = best_len[ii][jj][kk - 1] + 1
                        parent[ii][jj][kk] = (ii, jj, kk - 1)
                # Two moves match (first and third ghost)
                elif ghost0[ii - 1] == ghost2[kk - 1]:
                    if best_len[ii - 1][jj][kk - 1] <= best_len[ii][jj - 1][kk]:
                        best_len[ii][jj][kk] = best_len[ii - 1][jj][kk - 1] + 1
                        parent[ii][jj][kk] = (ii - 1, jj, kk - 1)
                    else:
                        best_len[ii][jj][kk] = best_len[ii][jj - 1][kk] + 1
                        parent[ii][jj][kk] = (ii, jj - 1, kk)
                # Two moves match (second and third gost)
                elif ghost1[jj - 1] == ghost2[kk - 1]:
                    if best_len[ii][jj - 1][kk - 1] <= best_len[ii - 1][jj][kk]:
                        best_len[ii][jj][kk] = best_len[ii][jj - 1][kk - 1] + 1
                        parent[ii][jj][kk] = (ii, jj - 1, kk - 1)
                    else:
                        best_len[ii][jj][kk] = best_len[ii - 1][jj][kk] + 1
                        parent[ii][jj][kk] = (ii - 1, jj, kk)
                # All moves distinct
                else:
                    if ((best_len[ii - 1][jj][kk] <= best_len[ii][jj - 1][kk]) and
                        (best_len[ii - 1][jj][kk] <= best_len[ii][jj][kk - 1])):
                        best_len[ii][jj][kk] = best_len[ii - 1][jj][kk] + 1
                        parent[ii][jj][kk] = (ii - 1, jj, kk)
                    elif ((best_len[ii][jj - 1][kk] <= best_len[ii - 1][jj][kk]) and
                          (best_len[ii][jj - 1][kk] <= best_len[ii][jj][kk - 1])):
                        best_len[ii][jj][kk] = best_len[ii][jj - 1][kk] + 1
                        parent[ii][jj][kk] = (ii, jj - 1, kk)
                    else:
                        best_len[ii][jj][kk] = best_len[ii][jj][kk - 1] + 1
                        parent[ii][jj][kk] = (ii, jj, kk - 1)

    # Compute solution by following parent pointers
    sol = []
    cur = (len0, len1, len2)
    sol_len = best_len[cur[0]][cur[1]][cur[2]]
    for ii in range(sol_len):
        next_pos = parent[cur[0]][cur[1]][cur[2]]
        if next_pos[0] != cur[0]:
            sol.append(ghost0[next_pos[0]])
        elif next_pos[1] != cur[1]:
            sol.append(ghost1[next_pos[1]])
        else:
            sol.append(ghost2[next_pos[2]])
        cur = next_pos

    return list(reversed(sol))


