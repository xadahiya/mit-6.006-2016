#!/usr/bin/env python

"""AVL tree implementation, by Erik Demaine et al. for 6.006

COMMAND-LINE USAGE:

    python avl.py 10 -- do 10 random insertions, printing AVL tree at each step
    python avl.py -d 10 -- do 10 random insertions, then 10 random deletions, printing AVL tree at each step

SHELL USAGE:

>>> import avl
>>> t = avl.AVL()
>>> print(t)
<empty tree>
>>> for i in range(4):
...   t.insert(i)
...
>>> print(t)
  1
 / \
0  2
/\ /\
    3
    /\
>>> t.delete_min()
>>> print(t)
  2
 / \
1  3
/\ /\

"""

import bst

def height(node):
    if node is None:
        return -1
    else:
        return node.height

def update_height(node):
    node.height = max(height(node.left), height(node.right)) + 1

class AVL(bst.BST):
    """
AVL binary search tree implementation.
Supports insert, delete, find, find_min, next_larger each in O(lg n) time.
"""
    def left_rotate(self, x):
        y = x.right
        y.parent = x.parent
        if y.parent is None:
            self.root = y
        else:
            if y.parent.left is x:
                y.parent.left = y
            elif y.parent.right is x:
                y.parent.right = y
        x.right = y.left
        if x.right is not None:
            x.right.parent = x
        y.left = x
        x.parent = y
        update_height(x)
        update_height(y)
        self.rotation_count += 1

    def right_rotate(self, x):
        y = x.left
        y.parent = x.parent
        if y.parent is None:
            self.root = y
        else:
            if y.parent.left is x:
                y.parent.left = y
            elif y.parent.right is x:
                y.parent.right = y
        x.left = y.right
        if x.left is not None:
            x.left.parent = x
        y.right = x
        x.parent = y
        update_height(x)
        update_height(y)
        self.rotation_count += 1

    def rebalance(self, node):
        while node is not None:
            update_height(node)
            if height(node.left) >= 2 + height(node.right):
                if height(node.left.left) >= height(node.left.right):
                    self.right_rotate(node)
                else:
                    self.left_rotate(node.left)
                    self.right_rotate(node)
            elif height(node.right) >= 2 + height(node.left):
                if height(node.right.right) >= height(node.right.left):
                    self.left_rotate(node)
                else:
                    self.right_rotate(node.right)
                    self.left_rotate(node)
            node = node.parent

    ## find(k), find_min(), and next_larger(k) inherited from bst.BST

    def insert(self, k):
        """Inserts a node with key k into the subtree rooted at this node.
        This AVL version guarantees the balance property: h = O(lg n).
        
        Args:
            k: The key of the node to be inserted.
        """
        node = super(AVL, self).insert(k)
        self.rotation_count = 0
        self.rebalance(node)
        print('\nInserting %d cost %d rotations' % (k, self.rotation_count))

    def delete(self, k):
        """Deletes and returns a node with key k if it exists from the BST.
        This AVL version guarantees the balance property: h = O(lg n).
        
        Args:
            k: The key of the node that we want to delete.
            
        Returns:
            The deleted node with key k.
        """
        node = super(AVL, self).delete(k)
        ## node.parent is actually the old parent of the node,
        ## which is the first potentially out-of-balance node.
        self.rotation_count = 0
        self.rebalance(node.parent)
        print('\nDeleting %d cost %d rotations' % (k, self.rotation_count))

def test(args=None):
    bst.test(args, BSTtype=AVL)

if __name__ == '__main__': test()
